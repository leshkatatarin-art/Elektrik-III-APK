ЭЛЕКТРИК — III ГРУППА ДО 1000 В
Android Studio project, версия 1.0

В проект встроен автономный тренажёр index.html. Вопросы и ответы находятся внутри HTML, интернет приложению не нужен. WebView разрешает JavaScript и локальное хранилище для избранного/прогресса.

КАК ПОЛУЧИТЬ APK:
1. Установить Android Studio на компьютер.
2. Распаковать архив ElektrikIII_Android.zip.
3. В Android Studio выбрать Open и указать папку ElektrikIII_Android.
4. Дождаться синхронизации Gradle (потребуется интернет для загрузки Android Gradle Plugin и SDK, если их ещё нет).
5. Выбрать Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Параметры: package ru.prokhorenko.elektrikiii; min Android 6.0 (API 23); version 1.0.
Разработчик: Прохоренко Алексей.

Примечание: это исходный Android Studio проект, не готовый APK. APK необходимо собрать Android SDK/Gradle.
